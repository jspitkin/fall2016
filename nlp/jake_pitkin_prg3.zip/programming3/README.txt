Jake Pitkin
u0891770

I wrote my program using Python 3 on CADE machine LAB1-37.

To my knowledge there are no known idiosyncracies, problems, or limitations of my program. 
