python3 basilisk.py human-seeds.txt contexts.txt
