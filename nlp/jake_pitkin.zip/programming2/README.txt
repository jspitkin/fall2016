Jake Pitkin
u0891770
CS 5340 - Natural Lanuage Processing
Prof. Ellen Riloff


I wrote my CKY parser using Python 2.7.x. I tested my code on CADE machine 1-18.

To my knowledge, there are no idiosyncracies, problems, or limitations of my program.
