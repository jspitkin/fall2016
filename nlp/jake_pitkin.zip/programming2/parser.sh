python parse.py grammar.txt sentences.txt
