Jake Pitkin
u0891770

I wrote my program using Python 2.7.

Simply run "sh run.sh" on any of the CADE machines to run my code.
