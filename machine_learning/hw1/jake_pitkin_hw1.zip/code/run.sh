python settingA1.py SettingA/training.data SettingA/training.data mushroomFeatures.data
python settingA2.py SettingA/CVSplits/training_00.data SettingA/CVSplits/training_01.data SettingA/CVSplits/training_02.data SettingA/CVSplits/training_03.data SettingA/CVSplits/training_04.data SettingA/CVSplits/training_05.data mushroomFeatures.data
python settingB1.py SettingB/training.data SettingB/test.data SettingA/training.data SettingA/test.data mushroomFeatures.data
python settingB2.py SettingB/CVSplits/training_00.data SettingB/CVSplits/training_01.data SettingB/CVSplits/training_02.data SettingB/CVSplits/training_03.data SettingB/CVSplits/training_04.data SettingB/CVSplits/training_05.data mushroomFeatures.data
python settingC.py SettingC/CVSplits/training_00.data SettingC/CVSplits/training_01.data SettingC/CVSplits/training_02.data SettingC/CVSplits/training_03.data SettingC/CVSplits/training_04.data SettingC/CVSplits/training_05.data mushroomFeatures.data
